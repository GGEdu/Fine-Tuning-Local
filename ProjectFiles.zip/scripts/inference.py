from unsloth import FastLanguageModel
from transformers import AutoTokenizer

model, tokenizer = FastLanguageModel.from_pretrained(
    "../models/astronomy_expert",
    max_seq_length=2048,
)

def ask(query):
    prompt = f"""### Instrucción:
Como experto en astronomía, responde de forma precisa y concisa.

### Pregunta:
{query}

### Respuesta:
"""
    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
    outputs = model.generate(
        **inputs,
        max_new_tokens=200,
        temperature=0.7,
        pad_token_id=tokenizer.eos_token_id,
    )
    return tokenizer.decode(outputs[0], skip_special_tokens=True).split("### Respuesta:")[1].strip()

# Ejemplo de uso
print(ask("¿Qué es un agujero negro?"))