#!/usr/bin/env python3

from unsloth import FastLanguageModel
from datasets import load_dataset
from trl import SFTTrainer
from transformers import TrainingArguments
from evaluate import load
import numpy as np
import os
from dotenv import load_dotenv
load_dotenv()  # Carga las variables del .env

# 1. Configuración inicial
model_name = "unsloth/DeepSeek-R1-Distill-Qwen-14B"
hf_token = os.getenv("HF_TOKEN") 
wandb_token = os.getenv("WB_TOKEN")

# 2. Plantilla de prompt
train_prompt = """### Instrucción:
Como experto en astronomía, responde de forma precisa y concisa.

### Pregunta:
{}

### Respuesta:
{}{}"""

# 3. Cargar y procesar datos
dataset = load_dataset("json", data_files={
    "train": "data/train_dataset.json",
    "validation": "data/val_dataset.json",
})

tokenizer = FastLanguageModel.get_tokenizer()

def format_data(examples):
    texts = []
    for q, a in zip(examples["question"], examples["answer"]):
        text = train_prompt.format(q, a, tokenizer.eos_token)
        texts.append(text)
    return {"text": texts}

dataset = dataset.map(format_data, batched=True)

# 4. Cargar modelo
model, _ = FastLanguageModel.from_pretrained(
    model_name=model_name,
    max_seq_length=2048,
    load_in_4bit=True,
    token=hf_token,
)

# 5. Configurar LoRA
model = FastLanguageModel.get_peft_model(
    model,
    r=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    lora_alpha=32,
    use_gradient_checkpointing=True,
)

# 6. Métricas de evaluación
rouge = load("rouge")

def compute_metrics(eval_pred):
    predictions, labels = eval_pred
    predictions = np.argmax(predictions, axis=-1)
    
    decoded_preds = tokenizer.batch_decode(predictions, skip_special_tokens=True)
    decoded_labels = tokenizer.batch_decode(labels, skip_special_tokens=True)
    
    return rouge.compute(
        predictions=decoded_preds, 
        references=decoded_labels, 
        use_stemmer=True
    )

# 7. Configuración de entrenamiento
training_args = TrainingArguments(
    per_device_train_batch_size=4,
    gradient_accumulation_steps=2,
    num_train_epochs=3,
    learning_rate=2e-5,
    fp16=True,
    logging_steps=10,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="rougeL",
    output_dir="/models/outputs",
)

# 8. Entrenador
trainer = SFTTrainer(
    model=model,
    train_dataset=dataset["train"],
    eval_dataset=dataset["validation"],
    dataset_text_field="text",
    max_seq_length=1024,
    args=training_args,
)

# 9. Iniciar entrenamiento
trainer.train()

# 10. Guardar modelo
model.save_pretrained_merged("/models/astronomy_expert", tokenizer, save_method="merged_16bit")