#!/usr/bin/env python3

from unsloth import FastLanguageModel
from datasets import load_dataset
from trl import SFTTrainer
from transformers import (
    AutoTokenizer,
    TrainingArguments,
    BitsAndBytesConfig,
)
import torch
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# 1. Modelo existente optimizado para CPU
model_name = "unsloth/Phi-3-mini-4k-instruct"  # Modelo sin cuantización específica para GPU
hf_token = os.getenv("HF_TOKEN")

# 2. Configuración de Quantización para CPU
bnb_config = BitsAndBytesConfig(
    load_in_8bit=False,  # Desactivar carga en 8-bit
    load_in_4bit=False,  # Desactivar carga en 4-bit
    llm_int8_enable_fp32_cpu_offload=False,  # Desactivar offload a CPU
)

# 3. Plantilla de entrenamiento
train_prompt = """[USER] Eres un astrónomo. Responde brevemente:
P: {}
A: {} [EOS]"""

# 4. Carga de Datos
try:
    dataset = load_dataset("json", data_files={"train": "data/train_dataset.json"})
    dataset = dataset["train"].train_test_split(test_size=0.1)
except Exception as e:
    raise RuntimeError(f"Error: {str(e)} - Verifica que 'data/train_dataset.json' exista y tenga el formato correcto.")

# 5. Tokenizador
tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    model_max_length=256,
    padding_side="right",
    token=hf_token,  # Usar 'token' en lugar de 'use_auth_token'
)
tokenizer.pad_token = tokenizer.eos_token

# 6. Carga del Modelo en CPU
model = FastLanguageModel.from_pretrained(
    model_name=model_name,
    max_seq_length=256,
    quantization_config=bnb_config,
    device_map={"": "cpu"},  # Asignar todo el modelo a la CPU
    token=hf_token,  # Usar 'token' en lugar de 'use_auth_token'
)

# 7. Configuración LoRA
model = FastLanguageModel.get_peft_model(
    model,
    r=2,  # Rank mínimo viable
    target_modules=["q_proj"],  # Solo módulo esencial
    lora_alpha=2,
    use_gradient_checkpointing=True,
)

# 8. Hiperparámetros de Entrenamiento
training_args = TrainingArguments(
    per_device_train_batch_size=1,
    gradient_accumulation_steps=64,
    optim="adamw_torch",  # Cambiar a 'adamw_torch' para compatibilidad con CPU
    learning_rate=1e-5,
    num_train_epochs=1,
    max_grad_norm=0.1,
    logging_steps=5,
    save_strategy="no",
    output_dir="models/outputs",
    remove_unused_columns=True,
    dataloader_pin_memory=False,
)

# 9. Preprocesado de Datos
def format_data(examples):
    return {"text": [
        train_prompt.format(q.strip(), a.strip()) 
        for q, a in zip(examples["question"], examples["answer"])
    ]}

dataset = dataset.map(format_data, batched=True, num_proc=1)

# 10. Entrenamiento
trainer = SFTTrainer(
    model=model,
    train_dataset=dataset["train"],
    dataset_text_field="text",
    max_seq_length=128,
    args=training_args,
    processing_class=tokenizer,  # Nota: 'tokenizer' está deprecado; en futuras versiones usar 'processing_class'
    packing=False,
)

# 11. Manejo de Memoria
try:
    with torch.inference_mode():
        trainer.train()
except Exception as e:
    print(f"""
    ERROR: {str(e)}
    Posibles soluciones:
    1. Reducir el tamaño del conjunto de datos.
    2. Verificar que la CPU tenga suficiente memoria disponible.
    3. Utilizar un modelo de menor tamaño.
    """)
    exit(1)

# 12. Guardado del Modelo
model.save_pretrained_merged(
    "models/astronomy_expert",
    tokenizer,
    save_method="merged",
)
