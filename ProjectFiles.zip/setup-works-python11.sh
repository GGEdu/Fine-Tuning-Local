#!/bin/bash

# -------------------------------------
# 0. Verificar e instalar Python 3.11 y dependencias
# -------------------------------------
echo "🐍 Verificando Python 3.11..."
if ! command -v python3.11 &> /dev/null; then
    echo "🔧 Instalando Python 3.11..."
    sudo apt-get update -y
    sudo apt-get install -y software-properties-common
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    sudo apt-get update -y
    sudo apt-get install -y python3.11 python3.11-dev python3.11-venv python3.11-full
else
    echo "✅ Python 3.11 ya está instalado."
fi

# Instalar dependencias generales
sudo apt-get install -y wget build-essential libssl-dev

# -------------------------------------
# 1. Crear entorno virtual con Python 3.11
# -------------------------------------
echo "🛠️ Creando entorno virtual con Python 3.11..."
rm -rf venv  # Eliminar entorno anterior si existe
python3.11 -m venv venv

# Activar entorno virtual
source venv/bin/activate

# -------------------------------------
# 2. Instalar pip actualizado
# -------------------------------------
echo "📦 Instalando y actualizando pip..."
curl -sS https://bootstrap.pypa.io/get-pip.py | python3.11
pip install --upgrade pip

# -------------------------------------
# 3. Instalar CUDA 12.4 manualmente
# -------------------------------------
echo "⚡ Instalando CUDA 12.4..."
CUDA_INSTALLED=$(ls /usr/local | grep cuda-12.4)
if [ -z "$CUDA_INSTALLED" ]; then
    echo "🔧 Descargando e instalando CUDA 12.4..."
    wget https://developer.download.nvidia.com/compute/cuda/12.4.0/local_installers/cuda_12.4.0_550.54.14_linux.run
    sudo sh cuda_12.4.0_550.54.14_linux.run --silent --toolkit --override
    rm cuda_12.4.0_550.54.14_linux.run
else
    echo "✅ CUDA 12.4 ya está instalado."
fi

# -------------------------------------
# 4. Configurar variables de entorno CUDA
# -------------------------------------
echo "⚙️  Configurando variables de entorno CUDA..."
if ! grep -q "cuda-12.4" ~/.bashrc; then
    echo '
# CUDA 12.4 Configuration
export PATH="/usr/local/cuda-12.4/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda-12.4/lib64:$LD_LIBRARY_PATH"
' >> ~/.bashrc
    echo "⚠️ Variables de CUDA añadidas a .bashrc"
else
    echo "✅ Variables de CUDA ya configuradas en .bashrc"
fi

# Actualizar enlaces simbólicos
sudo rm -f /usr/local/cuda
sudo ln -s /usr/local/cuda-12.4 /usr/local/cuda

# Recargar configuración
source ~/.bashrc

# -------------------------------------
# 5. Instalar PyTorch con soporte CUDA 12.4
# -------------------------------------
echo "🔥 Instalando PyTorch para CUDA 12.4..."
pip install --no-cache-dir "torch==2.4.0" --index-url https://download.pytorch.org/whl/cu124

# -------------------------------------
# 6. Compilar e instalar bitsandbytes desde fuente
# -------------------------------------
echo "🔨 Compilando bitsandbytes para CUDA 12.4..."
git clone https://github.com/TimDettmers/bitsandbytes.git
cd bitsandbytes
CUDA_VERSION=124 make cuda12x
python setup.py install
cd ..
rm -rf bitsandbytes

# -------------------------------------
# 7. Instalar dependencias restantes
# -------------------------------------
echo "📦 Instalando dependencias adicionales..."
pip install --no-cache-dir "triton==3.0.0" --extra-index-url https://download.pytorch.org/whl/nightly/cu124
pip install --no-cache-dir git+https://github.com/unslothai/unsloth_zoo.git
pip install --no-cache-dir git+https://github.com/unslothai/unsloth.git@main

# Instalar desde requirements.txt si existe
if [ -f requirements.txt ]; then
    pip install --no-cache-dir -r requirements.txt
else
    echo "⚠️ Archivo requirements.txt no encontrado, omitiendo instalación de paquetes adicionales."
fi

# -------------------------------------
# 8. Configurar variables de entorno en .env
# -------------------------------------
echo "🔐 Configurando variables de entorno..."
if [ ! -f .env ]; then
    cat << EOF > .env
export HF_TOKEN="tu_token_huggingface"
export WB_TOKEN="tu_token_wandb"
EOF
    echo "⚠️ Archivo .env creado. Completa los tokens antes de continuar!"
else
    echo "✅ Archivo .env ya existe. Verifica los tokens."
fi

echo "🚀 Configuración completada! Ejecuta 'source venv/bin/activate'"