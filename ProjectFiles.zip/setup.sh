#!/bin/bash

# -------------------------------------
# 0. Verificar e instalar dependencias del sistema
# -------------------------------------
echo "🐍 Comprobando instalación de Python y pip..."
sudo apt-get update -y
sudo apt-get upgrade -y
sudo apt autoremove -y

# Instalar paquetes esenciales
sudo apt-get install -y python3.12-full python3.12-dev python3.12-venv wget build-essential libssl-dev

# -------------------------------------
# 1. Crear entorno virtual
# -------------------------------------
echo "🛠️ Creando entorno virtual..."
if [ ! -d "venv" ]; then
    if python3.12 -m venv --without-pip venv; then
        echo "✅ Entorno virtual creado"
    else
        echo "❌ Error al crear el entorno virtual"
        exit 1
    fi
else
    echo "✅ Entorno virtual ya existe"
fi

# Activar entorno virtual
source venv/bin/activate

# Instalar paquetes esenciales
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py


# -------------------------------------
# 2. Instalar CUDA 12.4 y dependencias
# -------------------------------------
echo "🛠️  Verificando instalación de CUDA 12.4..."

# Comprobar si los paquetes CUDA ya están instalados
if ! command -v nvcc &> /dev/null || [ "$(nvcc --version | grep 'release' | awk '{print $6}')" != "12.4" ]; then
    echo "🔍 CUDA 12.4 no encontrado. Iniciando instalación..."
    
    # Descargar archivos solo si no existen
    if [ ! -f cuda-wsl-ubuntu.pin ]; then
        echo "🔍 CUDA 12.4 descargando paquete..."
        wget -q https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-wsl-ubuntu.pin
    fi
    
    sudo mv cuda-wsl-ubuntu.pin /etc/apt/preferences.d/cuda-repository-pin-600 2>/dev/null || true
    
    if [ ! -f cuda-repo-wsl-ubuntu-12-4-local_12.4.0-1_amd64.deb ]; then
        wget -q https://developer.download.nvidia.com/compute/cuda/12.4.0/local_installers/cuda-repo-wsl-ubuntu-12-4-local_12.4.0-1_amd64.deb
    fi
    
    # Instalar solo si el paquete no está ya instalado
    if ! dpkg -l | grep -q cuda-repo-wsl-ubuntu-12-4-local; then
        echo "🔍 CUDA 12.4 instalando paquete..."
        sudo dpkg -i cuda-repo-wsl-ubuntu-12-4-local_12.4.0-1_amd64.deb
    fi
    
    # Copiar keyring solo si no existe
    if [ ! -f /usr/share/keyrings/cuda-*-keyring.gpg ]; then
        sudo cp /var/cuda-repo-wsl-ubuntu-12-4-local/cuda-*-keyring.gpg /usr/share/keyrings/
    fi
    
    sudo apt-get update -y
    
    # Instalar herramientas CUDA solo si no están instaladas
    if ! dpkg -l | grep -q cuda-toolkit-12-4; then
        echo "🔍 CUDA 12.4 instalando paquete..."
        sudo apt install -y nvidia-cuda-toolkit
        sudo apt-get install -y nvidia-driver-535
        sudo apt-get install -y cuda-toolkit-12-4
    fi
else
    echo "✅ CUDA 12.4 ya está instalado."
fi

# -------------------------------------
# 3. Configurar variables de entorno CUDA
# -------------------------------------
echo "⚙️  Configurando variables de entorno CUDA..."
# Comprobar si las variables ya existen en el .bashrc
if ! grep -q "cuda-12.4" ~/.bashrc; then
    echo '
export PATH="/usr/local/cuda-12.4/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda-12.4/lib64:$LD_LIBRARY_PATH"
' >> ~/.bashrc
    echo "⚠️ Variables de CUDA añadidas al .bashrc"
else
    echo "✅ Variables de CUDA ya configuradas en .bashrc"
fi

# Recargar configuración
source ~/.bashrc

# -------------------------------------
# 4. Instalar dependencias Python
# -------------------------------------
echo "📦 Instalando paquetes Python..."
pip install --upgrade pip
pip install -r requirements.txt

# -------------------------------------
# 5. Configurar variables de entorno
# -------------------------------------
echo "🔐 Configurando variables de entorno..."
if [ ! -f .env ]; then
    cat << EOF > .env
export HF_TOKEN="tu_token_huggingface"
export WB_TOKEN="tu_token_wandb"
EOF
    echo "⚠️ Archivo .env creado. Completa los tokens antes de continuar!"
else
    echo "✅ Archivo .env ya existe. Verifica los tokens."
fi

echo "🚀 Configuración completada! Ejecuta 'source venv/bin/activate'"