#!/bin/bash

# -------------------------------------
# 0. Configuración de versión CUDA
# -------------------------------------
TARGET_CUDA_VERSION="12.8"
TORCH_CUDA_VERSION="cu124"  # PyTorch usa CUDA 12.4+ para compatibilidad con 12.8
SUPPORTED_DRIVER="535"

# -------------------------------------
# 0. Verificar e instalar dependencias del sistema
# -------------------------------------
echo "🐍 Comprobando instalación de Python y pip..."
sudo apt-get update -y
sudo apt-get upgrade -y
sudo apt autoremove -y

# Instalar paquetes esenciales
sudo apt-get install -y python3.12-full python3.12-dev python3.12-venv wget build-essential libssl-dev

# -------------------------------------
# 1. Crear entorno virtual
# -------------------------------------
echo "🛠️ Creando entorno virtual..."
if [ ! -d "venv" ]; then
    if python3.12 -m venv --without-pip venv; then
        echo "✅ Entorno virtual creado"
    else
        echo "❌ Error al crear el entorno virtual"
        exit 1
    fi
else
    echo "✅ Entorno virtual ya existe"
fi

# Activar entorno virtual
source venv/bin/activate

# Instalar paquetes esenciales
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py

# -------------------------------------
# 2. Instalar CUDA 12.8 y dependencias (WSL Optimizado)
# -------------------------------------
echo "🛠️  Verificando instalación de CUDA ${TARGET_CUDA_VERSION} para WSL..."

# Función para verificar versión de CUDA
check_cuda() {
    if command -v nvcc &> /dev/null && [ "$(nvcc --version | grep 'release' | awk '{print $6}')" == "${TARGET_CUDA_VERSION}" ]; then
        echo "✅ CUDA ${TARGET_CUDA_VERSION} ya está instalado."
        return 0
    else
        return 1
    fi
}

if ! check_cuda; then
    echo "🔍 CUDA ${TARGET_CUDA_VERSION} no encontrado. Iniciando instalación..."
    
    # Configuración inicial
    CUDA_PIN="cuda-wsl-ubuntu.pin"
    CUDA_DEB="cuda-repo-wsl-ubuntu-${TARGET_CUDA_VERSION//./-}-local_${TARGET_CUDA_VERSION}.0-1_amd64.deb"
    CUDA_URL="https://developer.download.nvidia.com/compute/cuda/${TARGET_CUDA_VERSION}.0/local_installers"

    # Método de instalación
    install_cuda() {
        echo "⬇️  Descargando paquete CUDA ${TARGET_CUDA_VERSION} para WSL (~3.5 GB)..."
        wget --tries=3 --retry-connrefused -q --show-progress \
            "${CUDA_URL}/${CUDA_DEB}" || return 1

        echo "🔧 Instalando paquete..."
        sudo dpkg -i ${CUDA_DEB} || return 2
        sudo cp /var/cuda-repo-wsl-ubuntu-*/cuda-*-keyring.gpg /usr/share/keyrings/
        
        echo "🔄 Actualizando repositorios..."
        sudo apt-get update -y || return 3
        
        echo "⚙️  Instalando CUDA Toolkit..."
        sudo apt-get install -y cuda-toolkit-${TARGET_CUDA_VERSION//./-} || return 4
        
        return 0
    }

    if ! install_cuda; then
        echo "❌ Error crítico en instalación de CUDA"
        echo "   Soluciones alternativas:"
        echo "   1. Actualizar WSL: wsl --update (desde PowerShell)"
        echo "   2. Descarga manual desde:"
        echo "      https://developer.nvidia.com/cuda-${TARGET_CUDA_VERSION}-0-download-archive"
        exit 1
    fi

    # Verificación final
    if check_cuda; then
        echo "🎉 CUDA ${TARGET_CUDA_VERSION} instalado exitosamente!"
        echo "   Driver Version: $(nvidia-smi | grep 'Driver Version' | awk '{print $6}')"
    else
        echo "❌ Fallo en la instalación de CUDA ${TARGET_CUDA_VERSION}"
        exit 1
    fi
fi

# -------------------------------------
# 3. Configurar variables de entorno CUDA
# -------------------------------------
echo "⚙️  Configurando variables de entorno..."
if ! grep -q "cuda-${TARGET_CUDA_VERSION}" ~/.bashrc; then
    echo "export PATH=\"/usr/local/cuda-${TARGET_CUDA_VERSION}/bin:\$PATH\"" >> ~/.bashrc
    echo "export LD_LIBRARY_PATH=\"/usr/local/cuda-${TARGET_CUDA_VERSION}/lib64:\$LD_LIBRARY_PATH\"" >> ~/.bashrc
    echo "⚠️ Variables de CUDA añadidas al .bashrc"
else
    echo "✅ Variables de CUDA ya configuradas en .bashrc"
fi

source ~/.bashrc

# -------------------------------------
# 4. Instalar dependencias Python (actualizadas para CUDA 12.8)
# -------------------------------------
echo "📦 Instalando paquetes Python..."
cat > requirements.txt << EOF
torch==2.3.0 --index-url https://download.pytorch.org/whl/${TORCH_CUDA_VERSION}
bitsandbytes==0.43.0
unsloth @ git+https://github.com/unslothai/unsloth.git
transformers==4.38.2
datasets==2.18.0
trl==0.7.11
evaluate==0.4.1
rouge-score==0.1.2
wandb==0.16.4
accelerate==0.27.2
python-dotenv==1.0.0
EOF

pip install --upgrade pip
pip install -r requirements.txt || {
    echo "❌ Error instalando dependencias. Intenta:";
    echo "   pip install --force-reinstall -r requirements.txt";
    exit 1;
}

# -------------------------------------
# 5. Configurar variables de entorno
# -------------------------------------
echo "🔐 Configurando variables de entorno..."
[ ! -f .env ] && cat << EOF > .env
export HF_TOKEN="tu_token_huggingface"
export WB_TOKEN="tu_token_wandb"
EOF

echo "🚀 Configuración completada! Ejecuta:"
echo "   source venv/bin/activate && python -c 'import torch; print(f\"PyTorch {torch.__version__} con CUDA {torch.version.cuda}\")'"